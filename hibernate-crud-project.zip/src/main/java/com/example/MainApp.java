
package com.example;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {

    public static void main(String[] args) {

        // INSERT
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Product p1 = new Product("Laptop","Gaming Laptop",75000,10);
        Product p2 = new Product("Mouse","Wireless Mouse",800,50);
        Product p3 = new Product("Keyboard","Mechanical Keyboard",2500,30);

        session.save(p1);
        session.save(p2);
        session.save(p3);

        tx.commit();
        session.close();

        // READ
        Session session2 = HibernateUtil.getSessionFactory().openSession();
        Product product = session2.get(Product.class,1);
        System.out.println("Retrieved: "+product);
        session2.close();

        // UPDATE
        Session session3 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx3 = session3.beginTransaction();

        Product updateProduct = session3.get(Product.class,1);
        updateProduct.setPrice(72000);
        updateProduct.setQuantity(8);

        session3.update(updateProduct);
        tx3.commit();
        session3.close();

        // DELETE
        Session session4 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx4 = session4.beginTransaction();

        Product deleteProduct = session4.get(Product.class,2);
        session4.delete(deleteProduct);

        tx4.commit();
        session4.close();

        HibernateUtil.getSessionFactory().close();

        System.out.println("CRUD Operations Completed.");
    }
}

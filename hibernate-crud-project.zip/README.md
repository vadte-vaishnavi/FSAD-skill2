
Hibernate CRUD Operations Project

Steps to Run:

1. Install MySQL and create database:
   CREATE DATABASE inventory_db;

2. Update username/password in hibernate.cfg.xml

3. Import project into IntelliJ / Eclipse as Maven project

4. Run MainApp.java

CRUD Included:
✔ Insert Products
✔ Retrieve Product by ID
✔ Update Product Price/Quantity
✔ Delete Product

ID Strategies:
Change this line in Product.java:
@GeneratedValue(strategy = GenerationType.AUTO)

You can test:
AUTO
IDENTITY
SEQUENCE
